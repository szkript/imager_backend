const express = require('express');
const router = express.Router();
const Customer = require('../models/Customer');

// Új ügyfél felvétele
router.post('/', async (req, res) => {
  const { name } = req.body;

  try {
    const newCustomer = new Customer({ name });
    await newCustomer.save();
    res.status(201).json(newCustomer);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

// Ügyfelek listázása
router.get('/', async (req, res) => {
  try {
    const customers = await Customer.find({});
    res.json(customers);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});
router.get('/:customerId', async (req, res) => {
  try {
      const customer = await Customer.findById(req.params.customerId);
      res.json(customer);
  } catch (error) {
      res.status(500).json({ message: 'Error fetching customer' });
  }
});
// Ügyfél törlése
router.delete('/:id', async (req, res) => {
  try {
    const customer = await Customer.findById(req.params.id);
    if (!customer) {
      return res.status(404).json({ message: 'Customer not found' });
    }
    await customer.remove();
    res.json({ message: 'Customer removed' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
});

module.exports = router;
