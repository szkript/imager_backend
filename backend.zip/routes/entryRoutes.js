const express = require('express');
const router = express.Router();
const Entry = require('../models/Entry');

router.get('/customer/:customerId', async (req, res) => {
    try {
      const entries = await Entry.find({ customer: req.params.customerId }).sort({ createdAt: -1 });
      res.json(entries);
    } catch (error) {
      console.error('Error fetching entries:', error); // Hibaüzenet a konzolon
      res.status(500).json({ message: 'Error fetching entries' });
    }
  });
  
  router.post('/', async (req, res) => {
    const { customer, text, imageBase64 } = req.body;
    try {
      const newEntry = new Entry({ customer, text, imageBase64 });
      await newEntry.save();
      res.status(201).json(newEntry);
    } catch (error) {
      console.error('Error adding entry:', error); // Hibaüzenet a konzolon
      res.status(500).json({ message: 'Error adding entry' });
    }
  });
  

module.exports = router;
