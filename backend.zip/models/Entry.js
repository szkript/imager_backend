const mongoose = require('mongoose');

const entrySchema = new mongoose.Schema({
    customer: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Customer',
      required: true,
    },
    text: {
      type: String,
      required: true,
    },
    imageBase64: {
      type: String,
    },
    createdAt: {
      type: Date,
      default: Date.now,  // Automatikusan beállítja a létrehozás idejét
    },
  });
  
  const Entry = mongoose.model('Entry', entrySchema);
  
  module.exports = Entry;